<?php include('db_connection.php');?>
<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<ul class="breadcrumb">
									<li class="breadcrumb-item active">Event Management</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /inv counter -->
					
					
					
				</div>	
				<!-- / table -->
				<?php include('events/eventmanagement/index.php');?>	
			</div>
			
		
        </div>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
		
    </body>
</html>