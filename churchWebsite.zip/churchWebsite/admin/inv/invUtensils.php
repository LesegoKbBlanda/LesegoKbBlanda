<?php include('tables/invUtensils/db_connection.php');?>
<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Inventory Utensils</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /inv counter -->
					
					<div class="row">
						<div class="col-sm-12">
							<div class="row">
								<div class="col-xl-3 col-sm-4 col-12">
									<div class="card">
										<div class="card-header lead text-center text-primary">Total Utensils Count</div>
										<div class="card-body">
											<h1 class="display-4 text-center text-primary">
											    <?php
													$sql = "SELECT quantity FROM inventory WHERE category_Code=03";

													//use for MySQLi-OOP
													$count=0;
													$query = $conn->query($sql);
													while($row = $query->fetch_assoc()){
														$count=$count+$row['quantity'];
													}
													echo $count;
												?>
											</h1>
										</div>
									</div>
								</div>
							</div>
						</div>			
					</div>
					
				</div>	
				<!-- /inv table -->
				<?php include('tables/invUtensils/index.php');?>	
			</div>
			
		
        </div>
		<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
		
    </body>
</html>