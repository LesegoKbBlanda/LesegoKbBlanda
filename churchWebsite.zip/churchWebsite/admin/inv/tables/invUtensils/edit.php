<?php
	session_start();
	include_once('db_connection.php');

	if(isset($_POST['edit'])){
		$id = $_POST['inv_id'];
		$category=$_POST['category'];
		$name = $_POST['name'];
		$unv = $_POST['Unavailable'];
		$sql = "UPDATE inventory SET Name = '$name', category_Code='$category' WHERE inv_id = '$id'";
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'updated successfully';
			echo $name;
			header('location: ../../invUtensils.php');
		}		
		else{
			$_SESSION['error'] = 'Something went wrong in updating';
			header('location: ../../invUtensils.php');
		}
	}
	else{
		$_SESSION['error'] = 'Select item to edit first';
		header('location: ../../invUtensils.php');
	}

?>