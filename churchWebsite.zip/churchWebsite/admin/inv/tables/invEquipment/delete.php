<?php
	session_start();
	include_once('db_connection.php');

	if(isset($_GET['id'])){
		$sql = "DELETE FROM inventory WHERE inv_id = '".$_GET['id']."'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'deleted successfully';
			header('location: ../../invEquipment.php');
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in deleting';
		}
	}
	else{
		$_SESSION['error'] = 'Select item to delete first';
	}
		echo "not working";
		header('location: ../../invEquipment.php');
?>