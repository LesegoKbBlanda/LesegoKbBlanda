<?php
	session_start();
	include_once('db_connection.php');

	if(isset($_POST['add'])){
		$name = $_POST['name'];
		$category = $_POST['category'];
		$qty = $_POST['qty'];
		$id = $_POST['inv_id'];
		$Unv =0;
		$Av = $_POST['qty'];
		$sql = "INSERT INTO inventory (category_Code,Name,inv_id,quantity,Unavailable,Available) VALUES ('$category','$name','$id','$qty','$Unv','$Av')";
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'added successfully';
			header('location: ../../invFurniture.php');
		}

		else{
			$_SESSION['error'] = 'Something went wrong while adding';
			header('location: ../../invFurniture.php');
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
		header('location: ../../invFurniture.php');
	}
?>