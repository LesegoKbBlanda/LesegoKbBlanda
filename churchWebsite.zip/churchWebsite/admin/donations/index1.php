
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href='donations/bootstrap/css/bootstrap.min.css'>
	<link rel="stylesheet" type="text/css" href='donations/datatable/dataTable.bootstrap.min.css'>
	<style>
		.height10{
			height:10px;
		}
		.mtop10{
			margin-top:10px;
		}
		.modal-label{
			position:relative;
			top:7px
		}
	</style>

</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<div class="row">
			</div>
			<div class="row">
			</div>
			<div class="height10">
			</div>
			<div class="row">
				<table id="myTable" class="table table-bordered table-striped">
					<thead>
						<th>id</th>
						<th>Name</th>
						<th>Payment Date</th>
						<th>(P)amount</th>
					</thead>
					<tbody>
						<?php
							include_once('C:\xampp\htdocs\ventura-user-management-php-script\admin\db_connection.php');
							$sql = "SELECT * FROM donateviavisa";
							//use for MySQLi-OOP
							$query = $conn->query($sql);
							while($row = $query->fetch_assoc()){
								echo 
								"<tr>
									<td>".$row['id']."</td>
									<td>".$row['username']."</td>
									<td>".$row['pdate']."</td>
									<td>".$row['amount']."</td>
									<td>
										<a href='#' class='btn btn-success btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-edit'></span> Print</a>
									</td>
								</tr>";
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script src='donations/jquery/jquery.min.js'></script>
<script src='donations/bootstrap/js/bootstrap.min.js'></script>
<script src='donations/datatable/jquery.dataTables.min.js'></script>
<script src='donations/datatable/dataTable.bootstrap.min.js'></script>
<!-- generate datatable on our table -->
<script>
$(document).ready(function(){
	//inialize datatable
    $('#myTable').DataTable();

    //hide alert
    $(document).on('click', '.close', function(){
    	$('.alert').hide();
    })
});
</script>
</body>

</html>