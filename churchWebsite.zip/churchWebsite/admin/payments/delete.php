<?php
	session_start();
	include_once('db_connection.php');

	if(isset($_GET['id'])){
		$sql = "DELETE FROM visa WHERE id = '".$_GET['id']."'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'deleted successfully';
			header('location: index.php');
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in deleting';
			header('location: index.php');
		}
	}
	else{
		$_SESSION['error'] = 'Select item to delete first';
	}
		echo "wtf";
		header('location: index.php');
?>