
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href='payments/bootstrap/css/bootstrap.min.css'>
	<link rel="stylesheet" type="text/css" href='payments/datatable/dataTable.bootstrap.min.css'>
	<style>
		.height10{
			height:10px;
		}
		.mtop10{
			margin-top:10px;
		}
		.modal-label{
			position:relative;
			top:7px
		}
	</style>

</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<div class="row">
			</div>
			<div class="row">
			</div>
			<div class="height10">
			</div>
			<div class="row">
				<table id="myTable" class="table table-bordered table-striped">
					<thead>
						<th>id</th>
						<th>Name</th>
						<th>Payment Date</th>
					</thead>
					<tbody>
						<?php
							include_once('C:\xampp\htdocs\ventura-user-management-php-script\admin\db_connection.php');
							$sql = "SELECT * FROM visa ORDER BY pdate DESC";
							//use for MySQLi-OOP
							$query = $conn->query($sql);
							while($row = $query->fetch_assoc()){
								echo 
								"<tr>
									<td>".$row['id']."</td>
									<td>".$row['username']."</td>
									<td>".$row['pdate']."</td>
									<td>
										<a href='#' class='btn btn-success btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-edit'></span> Print</a>
									</td>
								</tr>";
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script src='payments/jquery/jquery.min.js'></script>
<script src='payments/bootstrap/js/bootstrap.min.js'></script>
<script src='payments/datatable/jquery.dataTables.min.js'></script>
<script src='payments/datatable/dataTable.bootstrap.min.js'></script>
<!-- generate datatable on our table -->
<script>
$(document).ready(function(){
	//inialize datatable
    $('#myTable').DataTable();

    //hide alert
    $(document).on('click', '.close', function(){
    	$('.alert').hide();
    })
});
</script>
</body>

</html>