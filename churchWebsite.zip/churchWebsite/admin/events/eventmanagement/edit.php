<?php
	session_start();
	include_once('db_connection.php');

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$title=$_POST['title'];
		$description = $_POST['description'];
		$evDate = $_POST['evDate'];
		$sql = "UPDATE events SET title = '$title', description='$description', evDate='$evDate' WHERE id = '$id'";
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'updated successfully';
			header('location: index.php');
		}		
		else{
			$_SESSION['error'] = 'Something went wrong in updating';
			header('location: index.php');
		}
	}
	else{
		$_SESSION['error'] = 'Select item to edit first';
		header('location: index.php');
	}

?>