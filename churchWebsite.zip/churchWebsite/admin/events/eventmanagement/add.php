<?php
	include_once('db_connection.php');

	if(isset($_POST['add'])){
		$title = $_POST['title'];
		$description = $_POST['description'];
		$date = $_POST['date'];
		$status="active";
		$sql = "INSERT INTO events (title,description,evDate,status) VALUES ('$title','$description','$date','$status')";
		//use for MySQLi OOP
		if($conn->query($sql)){
			echo'added successfully';
			header('location: index.php');
		}

		else{
			echo 'Something went wrong while adding';
			header('location: index.php');
		}
	}
?>