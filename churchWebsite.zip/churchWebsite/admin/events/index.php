<?php
	include_once('db_connection.php');

	if(isset($_POST['submit'])){
		$title = $_POST['title'];
		$description = $_POST['description'];
		$date = $_POST['date'];
		$status="active";
		$sql = "INSERT INTO events (title,description,evDate,status) VALUES ('$title','$description','$date','$status')";
		//use for MySQLi OOP
		if($conn->query($sql)){
			echo'added successfully';
			//header('location: admin-events.php');
		}

		else{
			echo 'Something went wrong while adding';
			//header('location: admin-events.php');
		}
	}
?>
<body>
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Media</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						<div class="col-sm-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Add Church Event                          <button type="button" class="btn btn-primary" name="manage"><a style="color:white" target="_blank" href="events.php">Manage Events</a></button></h4>
									
								</div>
								<div class="card-body">
								<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
									<div class="form-group">
										<label for="exampleInputEmail1">Title</label>
										<input type="text" class="form-control"  placeholder="title" name="title">
									</div>
									<div class="form-group">
										<label for="exampleFormControlTextarea1">Description</label>
										<textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="description"></textarea>
									</div>
									<div class="form-group">
										<label>Date</label>
										<input type="date" class="form-control" name="date">
									</div>
									<button type="submit" class="btn btn-primary" name="submit">Submit</button>
								</form>
								</div>
							</div>
						</div>			
					</div>
					
				</div>			
			</div>
			<!-- /Page Wrapper -->
</body>

