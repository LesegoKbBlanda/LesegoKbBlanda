<?php include ('videos/db_connection.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
		
		<!-- Feathericon CSS -->
        <link rel="stylesheet" href="assets/css/feathericon.min.css">

        <!-- Datatables CSS -->
		<link rel="stylesheet" href="assets/plugins/datatables/datatables.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <title></title>
    </head>
    <body>
    <?php 


    //file upload
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $maxsize = 157286400;//150mb in bytes
        
        if(isset($_FILES['file']['name']) && $_FILES['file']['name']!=""){
            echo $date=$_POST['date'];
            echo $name=$_FILES['file']['name'];
            echo $vtype=$_POST['vtype'];

            //location
            if($vtype == "praise"){
                $target_dir = "videos/praise/";
                $target_file = $target_dir.$name;

                //FILE EXTENSION
                $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                //valid file extension
                $extension_arr = array("mp4","avi","3pg","mov","mpeg");

                //check extension
                if(in_array($extension,$extension_arr)){
                    
                    //check file size
                    if($_FILES['file']['size'] >= $maxsize){
                        $_SESSION['message'] = "file too large,file must be less than 150mb";
                    }else {
                        //upload
                        if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                            //insert record
                            $sql = "INSERT INTO videos (Name,Location,created,vtype) VALUES ('$name','$target_file','$date','$vtype')";
                            
                            if($conn->query($sql)){
                                $_SESSION['message'] = "Upload successful";
                            }else{
                                $_SESSION['message'] = "not unsuccessful";
                            }
                        }else {
                            $_SESSION['message'] = "database Upload unsuccessful";
                        }
                    }

                }else{
                    $_SESSION['message'] = "invalid file extention";
                }

            }elseif ($vtype == "worship") {
                $target_dir = "videos/worship/";
                $target_file = $target_dir.$name;

                //FILE EXTENSION
                $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                //valid file extension
                $extension_arr = array("mp4","avi","3pg","mov","mpeg");

                //check extension
                if(in_array($extension,$extension_arr)){
                    
                    //check file size
                    if($_FILES['file']['size'] >= $maxsize){
                        $_SESSION['message'] = "file too large,file must be less than 150mb";
                    }else {
                        //upload
                        if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                            //insert record
                            $sql = "INSERT INTO videos (Name,Location,created,vtype) VALUES ('$name','$target_file','$date','$vtype')";
                            
                            if($conn->query($sql)){
                                $_SESSION['message'] = "Upload successful";
                            }
                        }
                    }

                }else{
                    $_SESSION['message'] = "invalid file extention";
                }

            }elseif ($vtype == "service") {
                $target_dir = "videos/service/";
                $target_file = $target_dir.$name;

                //FILE EXTENSION
                $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                //valid file extension
                $extension_arr = array("mp4","avi","3pg","mov","mpeg");

                //check extension
                if(in_array($extension,$extension_arr)){
                    
                    //check file size
                    if($_FILES['file']['size'] >= $maxsize){
                        $_SESSION['message'] = "file too large,file must be less than 150mb";
                    }else {
                        //upload
                        if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                            //insert record
                            $sql = "INSERT INTO videos (Name,Location,created,vtype) VALUES ('$name','$target_file','$date','$vtype')";
                            
                            if($conn->query($sql)){
                                $_SESSION['message'] = "Upload successful";
                            }
                        }
                    }

                }else{
                    $_SESSION['message'] = "invalid file extention";
                }

            }else {
                $target_dir = "videos/others/";
                $target_file = $target_dir.$name;

                //FILE EXTENSION
                $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

                //valid file extension
                $extension_arr = array("mp4","avi","3pg","mov","mpeg");

                //check extension
                if(in_array($extension,$extension_arr)){
                    
                    //check file size
                    if($_FILES['file']['size'] >= $maxsize){
                        $_SESSION['message'] = "file too large,file must be less than 150mb";
                    }else {
                        //upload
                        if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                            //insert record
                            $sql = "INSERT INTO videos (Name,Location,created,vtype) VALUES ('$name','$target_file','$date','$vtype')";
                            
                            if($conn->query($sql)){
                                $_SESSION['message'] = "Upload successful";
                            }
                        }
                    }

                }else{
                    $_SESSION['message'] = "invalid file extention";
                }
            }

        }else {
            $_SESSION['message'] = "Please select file";

        }
    }
?>
        <!--upload responce-->
        <?php
            if(isset($_SESSION['message'])){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
        ?>


    <div class="page-wrapper">
        <div class="content container-fluid">
        <!--modal start-->
            	<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col-sm-12">
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="admin-media.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Videos</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
                    <div class="row">
						<div class="col-sm-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">videos</h4>
								</div>
								<div class="card-body">

                                        <!-- Modal -->
                                    
                                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Add Video</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" enctype="multipart/form-data">
                                                            <div class="input-group mb-3">
                                                                <label class="form-label">Type of video:  </label>
                                                                <select class="custom-select" id="inputGroupSelect02" name="vtype">
                                                                    <option selected>Choose...</option>
                                                                    <option value="praise">Praise</option>
                                                                    <option value="worship">Worship</option>
                                                                    <option value="service">Weekly Service</option>
                                                                    <option value="others">other</option>
                                                                </select>
                                                            </div>
                                                        <div class="mb-3">
                                                            <label class="sr-only" for="inlineFormInput">Date: </label>
                                                            <input type="date" class="form-control mb-2" name="date">
                                                        </div>
                                                        <div class="mb-3">
                                                                <label class="form-label">Select File: </label>
                                                                <input type="file" class="form-control-file" id="exampleFormControlFile1" name="file">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            <input type="submit" class="btn btn-primary"name="submit" value="Upload">
                                                        </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            
                                    <!--modal end-->
                                    <div class="card-body">

                                    <?php
                                        $fetchVideos = mysqli_query($conn,"SELECT * FROM videos ORDER BY created DESC");
                                        while($row = mysqli_fetch_assoc($fetchVideos)){
                                            $name = $row['Name'];
                                            $location = $row['Location'];

                                            echo "<div style='float: left; margin-right: 5px'>
                                            <video src='$location' controls width='320px' height='320px'>

                                            </video><br>
                                            <span>".$name."</span>
                                            </div> ";
                                         }
                                    ?></div>
                                </div>
							</div>
						</div>			
					</div>

            
            


        </div>
    </div>

        	<!-- jQuery -->
            <script src="assets/js/jquery-3.2.1.min.js"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		
		<!-- Datatables JS -->
		<script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
		<script src="assets/plugins/datatables/datatables.min.js"></script>
		
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
		
		<!-- Custom JS -->
		<script  src="assets/js/script.js"></script>

		<script  src="assets/php/js/feedback.js"></script>
    </body>
</html>
