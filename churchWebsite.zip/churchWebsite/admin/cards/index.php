<link rel="stylesheet" href="cards/style.css">
<section class="cards-wrapper">
    <div class="card-grid-space">
        <div class="num">01</div>
        <a target="_blank" class="card" href="inv/invFurniture.php" style="background-image: url('cards/img/church1.jpg');">
            <div>
                <br>
                <br>
                <br>
                <br>
                <br>
                <h1>Church Furniture</h1>
                <p>Table,chairs,altars,etc...</p>
                <div class="date">
                    <?php 
                    // Return date/time info of a timestamp; then format the output
                      $mydate=getdate(date("U"));
                      echo "$mydate[weekday], $mydate[month] $mydate[mday], $mydate[year]";
                     ?>
                </div>
                <div class="tags">
                    <div class="tag">Click for more</div>
                </div>
            </div>
        </a>
    </div>
    <div class="card-grid-space">
        <div class="num">02</div>
        <a target="_blank" class="card" href="inv/invEquipment.php" style="background-image: url('cards/img/church2.jpg');">
            <div>
                <br>
                <br>
                <br>
                <br>
                <br>
                <h1>Church Equipment</h1>
                <p>Music instruments,communication devices.....</p>
                <div class="date">
                <?php 
                    // Return date/time info of a timestamp; then format the output
                      $mydate=getdate(date("U"));
                      echo "$mydate[weekday], $mydate[month] $mydate[mday], $mydate[year]";
                     ?>
                </div>
                <div class="tags">
                    <div class="tag">Click for more</div>
                </div>
            </div>
        </a>
    </div>
    <div class="card-grid-space">
        <div class="num">03</div>
        <a target="_blank" class="card" href="inv/invUtensils.php" style="background-image: url('cards/img/church3.jpg');">
            <div>
                <br>
                <br>
                <br>
                <br>
                <br>
                <h1>Kitchen Utensils</h1>
                <p>Church Cutlary</p>
                <div class="date">
                    <?php 
                    // Return date/time info of a timestamp; then format the output
                      $mydate=getdate(date("U"));
                      echo "$mydate[weekday], $mydate[month] $mydate[mday], $mydate[year]";
                     ?>

                </div>
                <div class="tags">
                    <div class="tag">Click for more</div>
                </div>
            </div>
        </a>
    </div>
</section>