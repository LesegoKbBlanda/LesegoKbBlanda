Thank you for downloading this project.

---------------Ventura - User Management-------------

---------------want to run this project------------------

Step 1 : Extract .zip file to your website root folder.

Step 2 : Install database/user_management.sql file on phpmyadmin

Step 3 : Edit assets/php/config.php file data.

Step 4 : Edit assets/admin/php/config.php file data.

Now Enter : http://your site-url/    AND Admin Area: http://your site-url/admin

Default Password for Admin Account : admin

Enjoy This Project.

(Note: Internet Connection is Required for Sending E-Mails.).

Regards, CampCodes.com