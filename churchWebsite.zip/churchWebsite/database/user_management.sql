-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2021 at 10:34 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin@mail.com', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
(2, 'tumo', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `donate`
--

CREATE TABLE `donate` (
  `id` int(100) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(100) NOT NULL,
  `dtype` text NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `qty` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donate`
--

INSERT INTO `donate` (`id`, `fname`, `lname`, `email`, `phone`, `dtype`, `amount`, `qty`) VALUES
(1, 'bob', 'builder', 'bob@gmail.com', 74500111, 'Educational books', '0', 4),
(12, 'susan', 'mary', 'mary@gmail.com', 74500222, 'blankets', '1', 10),
(15, 'bob', 'builder', 'bob@gmail.com', 74500111, 'Educational books', '1', 4),
(28, 'Prof. Yirsaw', 'Ayalew', ' Aryalew@gmail.com', 75547635, ' books', '0', 12);

-- --------------------------------------------------------

--
-- Table structure for table `donateviavisa`
--

CREATE TABLE `donateviavisa` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `cardNumber` int(100) NOT NULL,
  `expmonth` text NOT NULL,
  `expyear` int(100) NOT NULL,
  `cvc` int(100) NOT NULL,
  `ctype` text NOT NULL,
  `pdate` date NOT NULL,
  `amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donateviavisa`
--

INSERT INTO `donateviavisa` (`id`, `username`, `cardNumber`, `expmonth`, `expyear`, `cvc`, `ctype`, `pdate`, `amount`) VALUES
(1, 'bob builder ', 1234892345, '01 - January', 2023, 567, 'visa', '2021-07-30', '500'),
(7, 'xyz ', 0, '02 - February', 2018, 5555, 'visa', '0000-00-00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(225) NOT NULL,
  `evDate` date NOT NULL,
  `status` enum('active','passed','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `evDate`, `status`) VALUES
(1, 'cook out', 'bring food and drinks', '2021-07-30', 'active'),
(3, 'bible study', 'discussions about the bible', '2021-08-04', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `feedback` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `replied` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active, 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `file_name`, `title`, `created`, `modified`, `status`) VALUES
(1, 'GOLD TEXT TEMPLATE.png', 'tumo img test 1', '2021-07-02 08:40:24', '2021-07-02 08:40:24', 1),
(2, 'TUMO.png', 'tumo img test 2', '2021-07-02 08:42:53', '2021-07-02 08:42:53', 1),
(3, 'pexels-photo-247431.jpeg', 'tumo img test 3', '2021-07-02 08:43:43', '2021-07-02 08:43:43', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `category_Code` enum('01','02','03','') NOT NULL,
  `Name` varchar(225) NOT NULL,
  `inv_id` varchar(150) NOT NULL,
  `quantity` int(100) NOT NULL,
  `Unavailable` int(100) NOT NULL,
  `Available` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`category_Code`, `Name`, `inv_id`, `quantity`, `Unavailable`, `Available`) VALUES
('01', 'Chairs', 'ch01', 100, 2, 98),
('02', 'keyboard', 'kb02', 3, 0, 3),
('02', 'microphone', 'mc02', 12, 0, 12),
('01', 'Podium', 'pd01', 6, 0, 6),
('03', 'Plate', 'pt03', 50, 0, 50),
('03', 'Spoon', 'sp03', 100, 0, 100),
('01', 'Tables', 'tb01', 15, 0, 15);

-- --------------------------------------------------------

--
-- Table structure for table `mastercard`
--

CREATE TABLE `mastercard` (
  `id` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `cardNumber` int(11) NOT NULL,
  `expmonth` int(11) NOT NULL,
  `expyear` int(11) NOT NULL,
  `cvc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mastercard`
--

INSERT INTO `mastercard` (`id`, `username`, `cardNumber`, `expmonth`, `expyear`, `cvc`) VALUES
(1, 0, 0, 0, 0, 0),
(2, 0, 55555, 0, 0, 2525),
(3, 0, 0, 0, 0, 0),
(4, 0, 525522, 5, 2018, 252),
(5, 0, 0, 0, 0, 0),
(6, 0, 0, 0, 0, 0),
(7, 0, 0, 0, 0, 0),
(8, 0, 2147483647, 8, 2018, 855);

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `note` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dob` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zip_code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `token_expire` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified` tinyint(4) NOT NULL DEFAULT 0,
  `deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `gender`, `dob`, `photo`, `address`, `city`, `state`, `zip_code`, `country`, `token`, `token_expire`, `created_at`, `verified`, `deleted`) VALUES
(11, 'frank franker', 'thor@gmail.com', '$2y$10$T9YkyBlOTE.fs4cRgTGmvusqh31wqkdWSu6eTHkokPdTdqay9GbVK', '', '', '', '', '', '', '', '', '', 'd6d6d0818bb73', '2021-06-22 07:01:23', '2021-06-22 06:51:23', 0, 0),
(12, 'tumo', 'playitstudio69@gmail.com', '$2y$10$wHY./rN2cknQYtRi4FwzLeAlCx/LXLrXkM9akZ0q9Uy1l7vhEnbAS', '77777777777', 'Male', '', '', '', '', '', '', '', '340de653d9ed7', '2021-07-05 09:21:32', '2021-06-25 01:38:37', 1, 0),
(13, 'bob builder', 'blackfikra@gmail.com', '$2y$10$jK04mcttWeLK2oFxOU5ZAujwFPuKF5tFRGWw.1QS6bvp1HwzXnytW', '', '', '', '', '', '', '', '', '', '098d363b2a455', '2021-06-25 01:57:07', '2021-06-25 01:47:07', 0, 0),
(14, 'morgan freeman', 'free@gmailcom', '$2y$10$PF75dlWrFVW0Un1Hq.8ivOR0ebGljbI3nhwkzj3MRyWfRQg1hUKTS', '', '', '', '', '', '', '', '', '', '14b0e2306410e', '2021-07-28 05:04:28', '2021-07-28 04:54:28', 0, 0),
(15, 'eden hazard', 'eharz@gmail.com', '$2y$10$tcR2sU8QgJrDVU0lSidZuu3g.B6bUg9cLz1vVDXvPEzntOU752EEu', '', '', '', '', '', '', '', '', '', '064e173bf0040', '2021-07-28 05:09:32', '2021-07-28 04:59:31', 0, 0),
(16, 'dan winschester', 'chster@gmail.com', '$2y$10$2GndWDLAA4qgRxgkzjOMTOrL19NlUR5jGPRnNUb9oIIugdQIUpnlW', '', '', '', '', '', '', '', '', '', '9b14ef0e60408', '2021-07-28 05:11:12', '2021-07-28 05:01:11', 0, 0),
(17, 'edison cavani', 'edicani@gmail.com', '$2y$10$lLhnpKmpRmj2CSnwWbBxm.jode3IP0YnDmPm34JWLRZm9sstFC3PC', '', '', '', '', '', '', '', '', '', '12305bc0342e6', '2021-07-28 05:13:32', '2021-07-28 05:03:32', 0, 0),
(18, 'randy savage', 'sav@gmail.com', '$2y$10$6LUZ94GJ9m2ZcMX8IDuig.rrIeq1qD7NX52.iYrrbF2kS7wkYgxOe', '', '', '', '', '', '', '', '', '', '1660621c120f3', '2021-07-28 08:32:26', '2021-07-28 08:22:26', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Location` varchar(255) NOT NULL,
  `created` date NOT NULL,
  `vtype` enum('worship','praise','service','others') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `Name`, `Location`, `created`, `vtype`) VALUES
(1, 'test vid.mp4', 'videos/praise/test vid.mp4', '2021-07-30', 'praise'),
(3, 'test vid 2.mp4', 'videos/praise/test vid 2.mp4', '2021-07-30', 'praise'),
(4, 'test vid.mp4', 'videos/service/test vid.mp4', '2021-07-30', 'service'),
(5, 'test vid 4.mp4', 'videos/worship/test vid 4.mp4', '2021-07-30', 'worship');

-- --------------------------------------------------------

--
-- Table structure for table `visa`
--

CREATE TABLE `visa` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `cardNumber` int(100) NOT NULL,
  `expmonth` varchar(255) NOT NULL,
  `expyear` int(255) NOT NULL,
  `cvc` int(100) NOT NULL,
  `pdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visa`
--

INSERT INTO `visa` (`id`, `username`, `cardNumber`, `expmonth`, `expyear`, `cvc`, `pdate`) VALUES
(1, 'thuto thata ', 2147483647, '0000-0001 - January', 2022, 555, '0000-00-00'),
(2, 'shenron ', 987654321, '01 - January', 2023, 555, '2021-07-30'),
(4, 'bob bulder ', 1234567890, '01 - January', 2024, 567, '2021-07-30'),
(10, 'susan ', 2147483647, '01 - January', 2022, 222, '2021-07-30'),
(12, 'lesego Kebokilwe ', 2147483647, '03 - March', 2023, 222, '2021-07-30'),
(16, 'leety luttece ', 1234892345, '01 - January', 2023, 52123, '2021-07-30');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(2) NOT NULL,
  `hits` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donate`
--
ALTER TABLE `donate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donateviavisa`
--
ALTER TABLE `donateviavisa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inv_id`);

--
-- Indexes for table `mastercard`
--
ALTER TABLE `mastercard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visa`
--
ALTER TABLE `visa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `donate`
--
ALTER TABLE `donate`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `donateviavisa`
--
ALTER TABLE `donateviavisa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mastercard`
--
ALTER TABLE `mastercard`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `visa`
--
ALTER TABLE `visa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
